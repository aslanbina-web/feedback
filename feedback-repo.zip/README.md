# Candor — peer feedback platform for business owners (Taiwan)

A community where business owners test each other's products/services and
leave honest, structured feedback. Built for the Taiwan market.

## Current status

`candor.html` is a **working prototype**, self-contained (open it directly
in a browser). It was built as a Claude artifact and uses `window.storage`
for persistence — that storage API only works when the file is opened
through Claude's artifact environment, not as a plain static file on its
own server. Treat this file as the **reference spec / UI source of truth**
for the real build, not as production code to deploy as-is.

## Core mechanics (already designed and validated in the prototype)

- **Sign-up**: LINE Login placeholder + manual name/business fallback so
  testing is never blocked.
- **Business card**: one card per member — name, category, address, url,
  what reviewers should test. This *is* what others swipe on.
- **Discover**: Tinder-style swipe deck (accept = "I'll test this",
  reject = skip). Drag or tap ✓ / ✕.
- **Daily quota**: scales with community size — `max(1, round(members / 25))`
  gives/receives per day. A card drops out of the deck for everyone once
  it hits its daily "received" cap; resets in a rolling window.
- **My Queue**: accepted cards you owe real feedback on — reviewed later,
  not at swipe time (real testing takes time).
- **My Card**: edit your listing, see feedback you've received (rating,
  pros/cons, recommend/not).

## Design direction (standing constraint — do not lose this on rebuild)

Minimal, low-decoration, "old video game" feel: flat colors, sharp corners
(except the circular rating "stamp" — the one signature element), no
drop shadows, no gradients, no motion except direct interaction (the
swipe). Fraunces (serif, headers) + IBM Plex Sans (body) + IBM Plex Mono
(numbers). Palette: bone `#EFEAE0`, ink `#1F2A22`, forest `#3D5A45`,
rust `#B8582F`.

## Roadmap (agreed plan, not yet built)

1. Real LINE Login (OAuth, no review needed — fast) replacing the
   placeholder button.
2. Real hosting (Vercel/Netlify) + real small database, replacing
   `window.storage`.
3. Install-to-home-screen prompt (PWA): native prompt on Android,
   manual Add-to-Home-Screen instructions on iOS. **Install before
   login** — iOS keeps Safari-tab storage separate from the home-screen
   app's storage, so logging in before installing leads to a confusing
   re-login.
4. Later: LINE MINI App certification (requires becoming a certified
   provider first in Taiwan specifically) for a real notification
   channel and no browser-storage fragility. Not needed for early
   testing.
5. Deliberately deferred for the first ~100-person test: UBN business
   verification, payments, anti-bot hardening, push notifications.

## Known open questions

- Daily quota reset: currently UTC-based; consider Taiwan timezone or a
  rolling per-user window (like Tinder/Bumble) instead of a fixed
  midnight reset.
- Reject currently doesn't count against a card's daily "received" cap —
  only accepts do. Revisit if this creates a loophole.
- Queue items have no expiry/nudge — stale unreviewed acceptances could
  pile up.
